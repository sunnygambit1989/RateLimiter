package com.blue.optima.ratelimiter.integration.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RateLimiterApplicationTests {

	@Test
	void contextLoads() {
	}

}
